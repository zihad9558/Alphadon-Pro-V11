package com.alphadon.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF070D0D)
private val Panel = Color(0xFF151923)
private val Cyan = Color(0xFF08B6D0)
private val Muted = Color(0xFF8B929F)
private val Green = Color(0xFF22C878)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlphadonApp() }
    }
}

@Composable
fun AlphadonApp() {
    var selectedPair by remember { mutableStateOf("EUR/USD") }
    var timeframe by remember { mutableStateOf("1m") }
    var tab by remember { mutableStateOf(1) }
    var activated by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Cyan,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF11151E), contentColor = Cyan) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Search, null) }, label = { Text("Signals") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.CreditCard, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("♞", color = Color(0xFF9B55E8), fontSize = 34.sp)
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text("ALPHADON", fontSize = 21.sp, fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp)
                                Text("PRO  •  V1.0", color = Cyan, fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold)
                            }
                        }
                        Icon(Icons.Default.Notifications, contentDescription = "Notifications",
                            tint = Color.LightGray, modifier = Modifier.size(28.dp))
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("HOME", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("  SIGNALS     PRICING     FAQ", color = Muted)
                    }
                }
                item {
                    Column(
                        Modifier.fillMaxWidth().border(1.dp, Color(0xFF252B37), RoundedCornerShape(24.dp))
                            .background(Color(0xFF111318), RoundedCornerShape(24.dp))
                            .padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("ALPHADON PRO", fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                                Text("⚡ ULTIMATE SIGNAL TERMINAL", color = Color(0xFFFFC342),
                                    fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Surface(color = if (activated) Green else Color(0xFFB93B43),
                                shape = RoundedCornerShape(20.dp)) {
                                Text(if (activated) "ACTIVE" else "DEMO",
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text("Choose your market", color = Muted, fontSize = 12.sp)
                        var pairExpanded by remember { mutableStateOf(false) }
                        Box {
                            OutlinedButton(onClick = { pairExpanded = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) {
                                Text("$selectedPair  •  OTC")
                                Spacer(Modifier.weight(1f))
                                Icon(Icons.Default.ExpandMore, null)
                            }
                            DropdownMenu(expanded = pairExpanded, onDismissRequest = { pairExpanded = false }) {
                                listOf("EUR/USD", "GBP/USD", "USD/JPY", "USD/TRY").forEach { pair ->
                                    DropdownMenuItem(text = { Text(pair) }, onClick = {
                                        selectedPair = pair; pairExpanded = false
                                    })
                                }
                            }
                        }
                        Text("TIMEFRAME", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("1m", "5m", "15m").forEach { tf ->
                                FilterChip(selected = timeframe == tf, onClick = { timeframe = tf },
                                    label = { Text(tf) })
                            }
                        }
                        Box(
                            Modifier.fillMaxWidth().height(190.dp)
                                .background(Color(0xFF050608), RoundedCornerShape(18.dp))
                                .border(1.dp, Color(0xFF202633), RoundedCornerShape(18.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Lock, null, tint = Cyan, modifier = Modifier.size(32.dp))
                                Spacer(Modifier.height(12.dp))
                                Text(if (activated) "DEMO SIGNAL PANEL" else "AWAITING ACTIVATION",
                                    color = Color.LightGray, letterSpacing = 2.sp,
                                    fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(if (activated) "Sample interface — connect a verified data source"
                                    else "Demo mode • no live signals", color = Muted, fontSize = 10.sp)
                            }
                        }
                        Button(onClick = { activated = !activated },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Cyan),
                            shape = RoundedCornerShape(14.dp)) {
                            Text(if (activated) "TURN DEMO OFF" else "PREVIEW DEMO MODE",
                                color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth().background(Color(0xFF0B2118),
                            RoundedCornerShape(16.dp)).padding(16.dp)) {
                        Icon(Icons.Default.Shield, null, tint = Green)
                        Spacer(Modifier.width(10.dp))
                        Text("Demo interface only. Trading involves risk; signals are not guaranteed profits.",
                            color = Color(0xFF75D99E), fontSize = 12.sp)
                    }
                }
                item {
                    Text("ALPHADON PRO  •  Built for learning", color = Muted,
                        fontSize = 11.sp, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}
