# Alphadon PRO — Android starter

A dark, FINORIX-inspired Android UI starter built with Kotlin and Jetpack Compose.

## Open and build
1. Install Android Studio (current stable).
2. Choose **Open** and select this `AlphadonPRO` folder.
3. Let Gradle sync; install Android SDK Platform 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press **Run**. To create an APK, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Included
- Alphadon PRO dark dashboard
- Pair selector and timeframe chips
- Home / Signals / Settings navigation shell
- Demo activation toggle and risk disclaimer

## Not included yet
- No real broker connection, market feed, trading execution, user accounts, payments,
  or live BUY/SELL recommendations. The signal panel is intentionally a demo placeholder.
- Add a trusted market-data provider and secure backend before implementing live data.
- Never put exchange API secrets in the Android app.
